need this versions:

nodejs: v16.14.2

NPM : 8.5.0