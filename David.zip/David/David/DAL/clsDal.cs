﻿using IT_Template;
using Microsoft.Data.SqlClient;
using System.Data;


namespace IT_Template.DAL
{
    public class clsDal
    {
        public static bool SaveUserApproveRequest_SaveUserRequest(int requestId)
        {
            using (var conn = new SqlConnection(Helpers.getConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("StoredProcedureName", conn))
                {
                    SqlDataAdapter sa = new SqlDataAdapter();

                    sa.SelectCommand = command;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("requestId", requestId);

                    SqlParameter sp = new SqlParameter("IsOk", SqlDbType.Bit);
                    sp.Direction = ParameterDirection.Output;
                    command.Parameters.Add(sp);
                    command.ExecuteNonQuery();
                }
                conn.Close();
            }
            return true;
        }
    }
}
