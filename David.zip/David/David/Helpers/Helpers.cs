﻿using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace IT_Template
{
    public static class Helpers
    {
        public static IHttpContextAccessor _accessor;
        public static IConfiguration _configuration;
     

        public static void SetInitElements(IHttpContextAccessor accesor, IConfiguration configuration)
        {
            _configuration = configuration;
            _accessor = accesor;
        }

        public static string getUserId()
        {
            string userName = "";
            return userName;
        }

        public static Guid getAppId()
        {
            var ret = Guid.Parse(Environment.GetEnvironmentVariable("AppId"));
            return ret;
        }

        public static string GetUserGroupsKey()
        {
            try
            {
                string UserGroupsKey = Helpers.getUserId() + "_" + _configuration.GetValue<string>("appName");
                return UserGroupsKey;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        internal static string getConnectionString()
        {
            SqlConnectionStringBuilder connectionStringBuilder = new SqlConnectionStringBuilder();
            connectionStringBuilder.DataSource = "";
            connectionStringBuilder.InitialCatalog = "DBname";
            connectionStringBuilder.UserID = Environment.GetEnvironmentVariable("");
            connectionStringBuilder.Password = Environment.GetEnvironmentVariable("");
            return connectionStringBuilder.ConnectionString;
        }
    }
}