﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Template_MVC_Vue.ViewModels
{
    public class IndexViewModel
    {
        public string Search { get; set; }
        public string Files { get; set; }
        public string agGridLicenseKey { get; set; }
    }
}
