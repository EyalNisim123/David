﻿using IT_Template;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Template_MVC_Vue.ViewModels;

namespace David.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MainController : ControllerBase
    {

        [HttpPost("SendMail")]
        public string SendMail()
        {
            return "gfdhfhfgh";
        }
    }
}
