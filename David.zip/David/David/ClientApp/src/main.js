import Vue from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify';
import Vuetify from 'vuetify/lib'
import router from './router'
import he from 'vuetify/es5/locale/he'
import axios from 'axios'
import '@mdi/font/css/materialdesignicons.css'
import VueSweetalert2 from 'vue-sweetalert2'
import Vuex from 'vuex'

import "ag-grid-enterprise";
/*import { LicenseManager } from "ag-grid-enterprise";*/
/*LicenseManager.setLicenseKey(window.ITGlobalConfig.agGridLicenseKey);*/
import '../node_modules/ag-grid-community/dist/styles/ag-grid.css';
import '../node_modules/ag-grid-community/dist/styles/ag-theme-alpine.css';
import '../node_modules/ag-grid-community/dist/styles/ag-theme-balham.css';
import '../node_modules/ag-grid-community/dist/styles/ag-theme-bootstrap.css';

Vue.prototype.$http = axios;

//axios.post("/api/main/SendMail", { withCredentials: true }).then((response) => {
//	console.log(response.data);
//});

Vue.use(Vuex);
Vue.use(axios);
Vue.use(VueSweetalert2);

const store = new Vuex.Store({
	state: {
		SearchUrl: null,
		FilesUrl: null,
	},
	mutations: {
		SetSearchUrl(state, SearchUrl) {
			state.SearchUrl = SearchUrl;
		},
		SetFilesUrl(state, FilesUrl) {
			state.FilesUrl = FilesUrl;
		}
	},


})

Vue.config.productionTip = false

export default new Vuetify({
	rtl: true,
})
new Vue({
	vuetify,
	store: store,
	icons: {
		iconfont: 'mdi'
	},
	router,
	lang: {
		locales: { he },
		current: 'he',
	},
	render: h => h(App)
}).$mount('#app')
