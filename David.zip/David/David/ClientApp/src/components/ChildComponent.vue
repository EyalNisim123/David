<template >


  <v-card elevation="8"   flat tile class="card-settings-dialog"> 
  <v-toolbar dark dense color="#163a58"> 
   <v-spacer style="width:30px"/>
    <v-toolbar-title >פרטים אישיים</v-toolbar-title>
    <v-spacer/>

    <v-btn dark flat v-on:click="closeDialog" icon>
      <v-icon>mdi-close</v-icon>
      </v-btn>
      </v-toolbar>


<v-row jestify="center">
  <v-col cols="20" sm="13" md="11" lg="12" >
    <v-card ref="form" elevation="8" outlined style="margin:10px" >
      <v-card-text>
        <v-text-field
        ref="name"
        v-model="name"
        :rules="[() => !!name || 'שדה חובה']"
        :error-messages="errorMessages"
        label="שם מלא"
        placeholder="הזן שם פרטי ושם משפחה"
        required
   
        ></v-text-field>
        <v-text-field
        ref="address"
        v-model="address"
        :rules="[
        () => !!address || 'שדה חובה',
        () => !!address && address.length <=25 || 'עד 25 תווים',addressCheck]"
         label="כתובת"
         placeholder="הזן רחוב ומספר בית"
         counter="25"
         required
        ></v-text-field>
          <v-text-field
          ref="city"
          v-model="city"
          :rules ="[() => !!city || 'שדה חובה',addressCheck]"
          label="עיר"
          placeholder="הזן עיר"
          required
         ></v-text-field>
         <v-text-field
         ref="zip"
         v-model="zip"
         :rules="[() => !!zip || 'שדה חובה']"
         label="מיקוד"
         placeholder="הזן מיקוד או תא דואר"
         required
         ></v-text-field>
         <v-autocomplete
         ref="country"
         v-model="country"
         :rules="[() => !!country || 'שדה חובה']"
         :items="countries"
         label="מדינה"
         placeholder="בחר מדינה"
          required
          ></v-autocomplete>
          </v-card-text>
        <v-divider class="mt-12" ></v-divider>
        <v-card-actions>
         <v-spacer></v-spacer>
          <v-slide-x-reverse-transition>
            <v-tooltip
            v-if="formHasErrors"
            left>
            <template v-slot:activator="{on, attrs}">
              <v-btn
              icon
              class="my-0"
              v-bind="attrs"
              @click="resetForm"
              v-on="on">            
              <v-icon>mdi-refresh</v-icon>
             </v-btn>
              </template>
             <span>נקה טופס</span>
           </v-tooltip>      
             </v-slide-x-reverse-transition>
                 <v-btn color="#163a58" outlined @click="submit">שמור</v-btn>
              </v-card-actions>
           
           </v-card>
            </v-col>
        </v-row>
    </v-card>
</template>
<script>
export default {
    data:() => ({
      testFiels:'',
      countries:['ישראל','איטליה','גרמניה','צרפת'],
      errorMessages: '',
      name: null,
      address: null,
      city: null,
      zip: null,
      country: null,
      formHasErrors: false,

    }),
   
    computed: {
      form()
      {
        return {
          name:this.name,
          address:this.address,
          city:this.city,
          zip:this.zip,
          country:this.country
        }
      }
    },
     methods: {
        closeDialog()
        {   
           this.resetForm();
         this.$emit('close-dialog')  ;
           
        },
        addressCheck()
        {
          this.errorMessages=this.address&& !this.name ? 'אנא הזן שם':''
          return true
        },
        resetForm (){
          this.errorMessages=[]
          this.formHasErrors=false
          Object.keys(this.form).forEach(f =>{this.$refs[f].reset()})
        },
        submit()
        {
          this.formHasErrors=false
           Object.keys(this.form).forEach(f =>{if (!this.form[f]) this.formHasErrors=true
           this.$refs[f].validate(true)       
           })
           if(this.formHasErrors==false)
          { 
               this.$swal.fire(
               'השמירה בוצעה בהצלחה',
                 '',
               'success',).then(this.resetForm() ,this.$emit('close-dialog'));         
           }
           else{
             this.$swal.fire(
               'שגיאה ',
              'אנא מלא את כל שדות החובה',
              'error', );   
           }
        },
    },
  
}
</script>

<style scoped>
.modal-header {
    padding: 5px;
    border-bottom: 1px solid #737373;
    background-color: rgb(98, 121, 141);;
    color: white;
    border-radius: 0;
}
.component-root1 {
  display: flex;
  width: 100%;
  flex-direction: column;

  background-color: whitesmoke;
  flex:1;
}
.card-settings-dialog {
  
  background-color: rgb(230, 230, 230);
}

</style>
