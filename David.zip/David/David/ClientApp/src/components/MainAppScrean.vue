<template>
	<div class="component-root">
		<v-card elevation="8" outlined class="card-settings">
			<v-card-title class="box-header" style="justify-content:space-between;">
				<div height="50px">חיפוש כללי</div>
			</v-card-title>

			<v-text-field outlined
						  v-model="search"
						  prepend-inner-icon="mdi-magnify"
						  label="הקלד ערך לחיפוש"
						  placeholder
						  class="my-input"
						  dense></v-text-field>
		</v-card>

		<v-card elevation="8" outlined class="card-settings" height="calc(100vh - 320px)">
			<v-card-title class="box-header">
				טבלה
				<label class="mx-1">|</label>
				<v-card-actions>
					<v-btn outlined x-small @click="showDialog=true" color="#28a745">
						<v-icon>mdi-plus</v-icon>חדש
					</v-btn>
					<v-btn outlined x-small @click="SendMail" color="#de9e14">
						<v-icon class="mx-1">mdi-send</v-icon>שלח מייל
					</v-btn>
					<v-btn outlined x-small v-on:click="alertDisplay" color="#0069d9">
						<v-icon class="mx-1">mdi-message-text-outline</v-icon>הודעה
					</v-btn>
				</v-card-actions>
			</v-card-title>

			<ag-grid-vue style="width:100%;height:500px" class="ag-theme-balham"
						 :columnDefs="ColumnDefs"
						 :rowData="rowData"

						 @grid-ready="onGridReady">
			</ag-grid-vue>

		</v-card>

		<v-dialog persistent v-model="showDialog" width="500px" hide-overlay>
			<ChildComponent v-on:close-dialog="closeDialog" />
		</v-dialog>

		<v-card elevation="8" outlined class="card-settings" height="10px">
			<v-card-title class="box-header">
				התראות
				<label class="mx-1">|</label>
				<v-card-actions>
					<v-btn outlined x-small @click="showAlert('success')" color="#28a745">
						<v-icon>mdi-check</v-icon>אישור
					</v-btn>
					<v-btn outlined x-small color="#de9e14" @click="showAlert('warning')">
						<v-icon class="mx-1">mdi-alert-circle</v-icon>אזהרה
					</v-btn>
					<v-btn outlined x-small color="#d4260f" @click="showAlert('error')">
						<v-icon class="mx-1">mdi-alert</v-icon>שגיאה
					</v-btn>
					<v-btn outlined x-small color="#0069d9" @click="showAlert('info')">
						<v-icon class="mx-1">mdi-message-text-outline</v-icon>מידע
					</v-btn>
				</v-card-actions>
			</v-card-title>
			<v-alert prominent :type="msgType" v-if="alert">התראה</v-alert>
		</v-card>
	</div>
</template>


<script>
	import ChildComponent from "./ChildComponent.vue";
	import { AgGridVue } from 'ag-grid-vue';
	import axios from 'axios';

	var backendUrl = window.location.origin;

	const api = axios.create({ baseURL: backendUrl, headers: { 'Content-Type': 'application/json' } });

	export default {
		components: { ChildComponent, AgGridVue },
		name: "MainTable",
		data: () => ({
			initValue: null,

			gridApi: null,
			columnApi: null,
			rowData: null,
			ColumnDefs: null,

			msgType: null,
			showDialog: false,
			alert: false,
			tester: false,
			text1: "הנתונים נשמרו בהצלחה",
			vartical: true,
			search: "",

			desserts: [
				{
					name: "Frozen Yogurt",
					calories: 159,
					fat: 6.0,
					carbs: 24,
					protein: 4.0,
					iron: "1%",
				},
				{
					name: "Ice cream sandwich",
					calories: 237,
					fat: 9.0,
					carbs: 37,
					protein: 4.3,
					iron: "1%",
				},
				{
					name: "Eclair",
					calories: 262,
					fat: 16.0,
					carbs: 23,
					protein: 6.0,
					iron: "7%",
				},
				{
					name: "Cupcake",
					calories: 305,
					fat: 3.7,
					carbs: 67,
					protein: 4.3,
					iron: "8%",
				},
				{
					name: "Gingerbread",
					calories: 356,
					fat: 16.0,
					carbs: 49,
					protein: 3.9,
					iron: "16%",
				},
				{
					name: "Jelly bean",
					calories: 375,
					fat: 0.0,
					carbs: 94,
					protein: 0.0,
					iron: "0%",
				},
				{
					name: "Lollipop",
					calories: 392,
					fat: 0.2,
					carbs: 98,
					protein: 0,
					iron: "2%",
				},
				{
					name: "Honeycomb",
					calories: 408,
					fat: 3.2,
					carbs: 87,
					protein: 6.5,
					iron: "45%",
				},
				{
					name: "Donut",
					calories: 452,
					fat: 25.0,
					carbs: 51,
					protein: 4.9,
					iron: "22%",
				},
				{
					name: "KitKat",
					calories: 518,
					fat: 26.0,
					carbs: 65,
					protein: 7,
					iron: "6%",
				},
			],
		}),

		computed: {
			backendUrl() {
				return this.$store.commit("IsRouteAllowed", false);
			},
		},
		methods: {
			onGridReady(params) {
				this.gridApi = params.api;
				this.columnApi = params.columnApi;
				this.gridApi.sizeColumnsToFit();
			},
			ExortToCsc() {
				this.gridApi.exortDataAsExcel();
			},

			alertDisplay() {
				this.$store.state.BackendUrl;
				this.$swal.fire("הודעת אישור", "בלה בלה", "success");
			},
			SendMail() {
                api.post("/api/main/SendMail").then((response) => {
					console.log(response.data);
				});
			},
			closeDialog: function () {
				this.showDialog = false;
			},
			showAlert: function (type) {
				this.tester = !this.tester;
				this.msgType = type;
				this.alert = true;
			},
			hide_alert: function (event) {
				window.setInterval(() => {
					this.alert = false;
				}, 4000);
			},
		},
		beforeMount() {
			this.ColumnDefs = [
				{ field: "name" },
				{ field: "calories" },
				{ field: "fat" }
			];
			this.rowData = this.desserts;
			
		},
		mounted: function () {
			
			if (alert) {
				this.hide_alert();
			}
		},
		//prevent route if needed
		beforeRouteLeave: function (to, from, next) {
			//you can access 'this'
			//to prevent route:  next(false);
			next();
		},
		//////////////////////////
	};
</script>


<style>
 .my-input {
		height: 50px !important;
	}

	.component-root {
		display: flex;
		width: 100%;
		flex-direction: column;
		height: calc(100vh - 110px);
		background-color: whitesmoke;
		flex: 1;
	}

	.card-settings {
		background-color: white;
		box-shadow: 0 1px 8px 0 rgba(0, 0, 0, 0.2), 0 3px 4px 0 rgba(0, 0, 0, 0.14), 0 3px 3px -2px rgba(0, 0, 0, 0.12);
		margin: 10px;
		padding: 10px;
	}

	.box-header {
		margin: -10px;
		margin-bottom: 5px;
		background: -moz-linear-gradient(top, #bccecf 1%, white 100%);
		background: -webkit-linear-gradient(top, #bccecf 1%, white 100%);
		/* background: linear-gradient(to bottom, #acc0c3 1%,white 100%); */
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#bccecf', endColorstr='white',GradientType=0 );
		padding: 4px 10px;
		font-weight: bold;
		font-size: 14px;
		-ms-user-select: none;
		user-select: none;
		line-height: 1.9;
	}

	.v-btn {
		text-overflow: ellipsis !important;
		font-size: 16px !important;
		height: 30px !important;
		margin-right: 5px;
		display: inline-block;
		text-align: center;
		white-space: nowrap;
		vertical-align: middle;
	}

	.label {
		display: inline-block;
		margin-bottom: 0.5rem;
	}

	.v-text-field.v-input.__control.v-inpt__slot {
		min-height: auto !important;
		display: flex !important;
		align-items: center !important;
	}

	.v-data-table.elevation-8.v-data-table--fixed-height.theme--light {
		height: 0px;
	}

	.v-alert {
		position: absolute !important;
		margin-right: 1500px;
		bottom: -10px !important;
		opacity: 0.8 !important;
		width: 300px;
		transition: "slide-y-transition";
	}

	.swal2-title {
		font-family: Arial, Helvetica, sans-serif;
	}

	.swal2-content {
		font-family: Arial, Helvetica, sans-serif;
	}

	.swal2-confirm {
		font-family: Arial, Helvetica, sans-serif;
	}
</style>





