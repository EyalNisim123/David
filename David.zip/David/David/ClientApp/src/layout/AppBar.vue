﻿<template>
    <div style="justify-content: center; text-align: center">
        <v-app-bar color="#163a58"
                   width="100%"
                   dark
                   dense
                   absolute
                   center
                   clipped-right
                   app>
            <v-toolbar-title>שם האפליקציה</v-toolbar-title>
            <v-spacer></v-spacer>
            <v-divider vertical></v-divider>
            <div>
                <img style="height: 50px; width: 210px; margin-top: 10px"
                     src="MinhalName.png" />
                <img style="height: 50px; width: 100px; margin-top: 7px"
                     src="MinhalLogo.png" />
            </div>
        </v-app-bar>
    </div>
</template>

<script>
    export default {
        name: "AppBar",
    };
</script>
