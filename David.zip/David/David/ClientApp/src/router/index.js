import Vue from 'vue'
import VueRouter from 'vue-router'
import MainAppScrean from '../components/MainAppScrean'

Vue.use(VueRouter)

const routes = [
	{
		path: '/',
		name: 'MainAppScrean',
		component: MainAppScrean,
		
	}

]

const router = new VueRouter({
	routes
})


export default router
